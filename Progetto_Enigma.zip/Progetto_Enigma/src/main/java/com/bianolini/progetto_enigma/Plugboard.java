package com.bianolini.progetto_enigma;

import java.util.HashMap;
import java.util.Map;


public class Plugboard {
    private Map <Character, Character> coppie;


    public Plugboard() {
        coppie = new HashMap<>();
    }

    public void aggiungiCoppia(Character a, Character b) {
        if (a == b) {
            throw new IllegalArgumentException("Non puoi collegare una lettera con se stessa");
        }
        if (coppie.containsKey(a) || coppie.containsKey(b)) {
            throw new IllegalArgumentException("Una delle lettere è già collegata");
        }
        coppie.put(a, b);
        coppie.put(b, a);
    }

    public int scambia(int segnale) {

        char lettera = (char) ('A' + segnale);

        if (coppie.containsKey((Character) lettera)) {
            char sostituita = coppie.get((Character) lettera);
            return sostituita - 'A';
        }
        return segnale;
    }
}