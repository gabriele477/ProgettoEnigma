package com.bianolini.progetto_enigma;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;

public class EnigmaController {

    @FXML
    private GridPane gridButton;

    @FXML
    private GridPane gridLampada;

    @FXML
    private GridPane gridPlugboard;

    @FXML
    private Label displayRotore1;

    @FXML
    private Label displayRotore2;

    @FXML
    private Label displayRotore3;

    @FXML
    private TextArea inputArea;

    @FXML
    private TextArea outputArea;

    private Button[] buttons;

    private Label[] lampade;

    private Label[] plugboardLabels;

    private MacchinaEnigma macchina;

    private Label primaSelezionata = null;

    private int contatoreCaratteri = 0;

    private int contatoreCoppie = 0;

    private static final String stileTasto =
            "-fx-background-color: #4a4a4a; -fx-text-fill: #e8d5a3; -fx-font-weight: bold; " +
                    "-fx-background-radius: 18; -fx-border-color: #666666; -fx-border-radius: 18; -fx-border-width: 1;";

    private static final String stileLampadaOff =
            "-fx-background-color: #2e2e2e; -fx-text-fill: #555555; -fx-font-weight: bold; " +
                    "-fx-background-radius: 18; -fx-border-color: #444444; -fx-border-radius: 18; -fx-border-width: 1;";

    private static final String stileLampadaOn =
            "-fx-background-color: #f5e642; -fx-text-fill: #1a1a1a; -fx-font-weight: bold; " +
                    "-fx-background-radius: 18; -fx-border-color: #c8b800; -fx-border-radius: 18; -fx-border-width: 1;";

    private static final String stilePlugLibero =
            "-fx-background-color: #2e2e2e; -fx-text-fill: #aaaaaa; -fx-font-weight: bold; " +
                    "-fx-background-radius: 50; -fx-border-color: #555555; -fx-border-radius: 50; -fx-border-width: 1;";

    private static final String stilePlugSelezionato =
            "-fx-background-color: #4a90d9; -fx-text-fill: #ffffff; -fx-font-weight: bold; " +
                    "-fx-background-radius: 50; -fx-border-color: #2266aa; -fx-border-radius: 50; -fx-border-width: 1;";

    private static final String stilePlugErrore =
            "-fx-background-color: #c0392b; -fx-text-fill: #ffffff; -fx-font-weight: bold; " +
                    "-fx-background-radius: 50; -fx-border-color: #922b21; -fx-border-radius: 50; -fx-border-width: 1;";

    private static final String[] stilePlugCoppie = {
            "-fx-background-color: #27ae60; -fx-text-fill: #ffffff; -fx-font-weight: bold; -fx-background-radius: 50; -fx-border-color: #1e8449; -fx-border-radius: 50; -fx-border-width: 1;",
            "-fx-background-color: #e67e22; -fx-text-fill: #ffffff; -fx-font-weight: bold; -fx-background-radius: 50; -fx-border-color: #ca6f1e; -fx-border-radius: 50; -fx-border-width: 1;",
            "-fx-background-color: #8e44ad; -fx-text-fill: #ffffff; -fx-font-weight: bold; -fx-background-radius: 50; -fx-border-color: #6c3483; -fx-border-radius: 50; -fx-border-width: 1;",
            "-fx-background-color: #16a085; -fx-text-fill: #ffffff; -fx-font-weight: bold; -fx-background-radius: 50; -fx-border-color: #117a65; -fx-border-radius: 50; -fx-border-width: 1;",
            "-fx-background-color: #d35400; -fx-text-fill: #ffffff; -fx-font-weight: bold; -fx-background-radius: 50; -fx-border-color: #a04000; -fx-border-radius: 50; -fx-border-width: 1;",
            "-fx-background-color: #2980b9; -fx-text-fill: #ffffff; -fx-font-weight: bold; -fx-background-radius: 50; -fx-border-color: #1f618d; -fx-border-radius: 50; -fx-border-width: 1;",
            "-fx-background-color: #c0392b; -fx-text-fill: #ffffff; -fx-font-weight: bold; -fx-background-radius: 50; -fx-border-color: #922b21; -fx-border-radius: 50; -fx-border-width: 1;",
            "-fx-background-color: #7d6608; -fx-text-fill: #ffffff; -fx-font-weight: bold; -fx-background-radius: 50; -fx-border-color: #5d4e08; -fx-border-radius: 50; -fx-border-width: 1;",
            "-fx-background-color: #117a65; -fx-text-fill: #ffffff; -fx-font-weight: bold; -fx-background-radius: 50; -fx-border-color: #0e6655; -fx-border-radius: 50; -fx-border-width: 1;",
            "-fx-background-color: #6c3483; -fx-text-fill: #ffffff; -fx-font-weight: bold; -fx-background-radius: 50; -fx-border-color: #4a235a; -fx-border-radius: 50; -fx-border-width: 1;"
    };

    @FXML
    void initialize() {
        buttons = new Button[26];
        char lettera = 'A';
        gridButton.setHgap(10);
        gridButton.setVgap(10);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 9; j++) {
                buttons[i * 9 + j] = new Button("" + lettera);
                buttons[i * 9 + j].setPrefWidth(800.0 / 10);
                buttons[i * 9 + j].setPrefHeight(36.0);
                buttons[i * 9 + j].setStyle(stileTasto);
                final char finalLettera = lettera;
                buttons[i * 9 + j].setOnAction(e -> {
                    System.out.println(e.getSource());
                    System.out.println(finalLettera);
                    char cifrata = macchina.cifraLettera(finalLettera);
                    contatoreCaratteri++;
                    if (contatoreCaratteri % 5 == 0) {
                        inputArea.appendText("" + finalLettera + " ");
                        outputArea.appendText("" + cifrata + " ");
                    } else {
                        inputArea.appendText("" + finalLettera);
                        outputArea.appendText("" + cifrata);
                    }
                    aggiornaLampada(cifrata);
                    aggiornaDisplayRotori();
                });
                gridButton.add(buttons[i * 9 + j], j, i, 1, 1);
                lettera++;
                if (lettera == '[') break;
            }
            if (lettera == '[') break;
        }

        Rotore r1 = new Rotore("EKMFLGDQVZNTOWYHXUSPAIBRCJ", 'Q');
        Rotore r2 = new Rotore("AJDKSIRUXBLHWTMCQGZNPYFVOE", 'E');
        Rotore r3 = new Rotore("BDFHJLCPRTXVZNYEIWGAKMUSQO", 'V');
        Riflettore rf = new Riflettore("YRUHQSLDPXNGOKMIEBFZCWVJAT");
        Plugboard pb = new Plugboard();
        macchina = new MacchinaEnigma(r1, r2, r3, rf, pb);

        lampade = new Label[26];
        char lamp = 'A';
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 9; j++) {
                int idx = i * 9 + j;
                if (idx >= 26) break;
                lampade[idx] = new Label("" + lamp);
                lampade[idx].setPrefWidth(800.0 / 10);
                lampade[idx].setPrefHeight(36.0);
                lampade[idx].setAlignment(javafx.geometry.Pos.CENTER);
                lampade[idx].setStyle(stileLampadaOff);
                gridLampada.add(lampade[idx], j, i, 1, 1);
                lamp++;
            }
        }

        plugboardLabels = new Label[26];
        char plug = 'A';
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 9; j++) {
                int idx = i * 9 + j;
                if (idx >= 26) break;
                plugboardLabels[idx] = new Label("" + plug);
                plugboardLabels[idx].setPrefWidth(38.0);
                plugboardLabels[idx].setPrefHeight(38.0);
                plugboardLabels[idx].setAlignment(javafx.geometry.Pos.CENTER);
                plugboardLabels[idx].setStyle(stilePlugLibero);
                final int finalIdx = idx;
                plugboardLabels[idx].setOnMouseClicked(e -> onPlugboardClick(finalIdx));
                gridPlugboard.add(plugboardLabels[idx], j, i, 1, 1);
                plug++;
            }
        }

        aggiornaDisplayRotori();
    }

    public void onKeyPressed(KeyEvent keyEvent) {
        if (keyEvent.getCode() == KeyCode.SPACE) {
            keyEvent.consume();
            return;
        }
        if (keyEvent.getCode().isLetterKey()) {
            int pos = (keyEvent.getCode().getChar().charAt(0) - 'A');
            buttons[pos].fire();
            buttons[pos].requestFocus();
            System.out.println("" + pos);
        }
    }

    private void aggiornaLampada(char accesa) {
        for (int i = 0; i < 26; i++) {
            if ((char) ('A' + i) == accesa) {
                lampade[i].setStyle(stileLampadaOn);
            } else {
                lampade[i].setStyle(stileLampadaOff);
            }
        }
    }

    private void aggiornaDisplayRotori() {
        displayRotore1.setText("" + (char) ('A' + macchina.getRotore1().getPosizione()));
        displayRotore2.setText("" + (char) ('A' + macchina.getRotore2().getPosizione()));
        displayRotore3.setText("" + (char) ('A' + macchina.getRotore3().getPosizione()));
    }

    private void onPlugboardClick(int idx) {
        Label cliccata = plugboardLabels[idx];
        char lettera = (char) ('A' + idx);

        if (primaSelezionata == null) {
            if (!cliccata.getStyle().equals(stilePlugLibero)) return;
            primaSelezionata = cliccata;
            cliccata.setStyle(stilePlugSelezionato);
        } else if (primaSelezionata == cliccata) {
            primaSelezionata.setStyle(stilePlugLibero);
            primaSelezionata = null;
        } else {
            char prima = primaSelezionata.getText().charAt(0);
            try {
                macchina.getPlugboard().aggiungiCoppia(prima, lettera);
                String colore = stilePlugCoppie[contatoreCoppie % stilePlugCoppie.length];
                contatoreCoppie++;
                primaSelezionata.setStyle(colore);
                cliccata.setStyle(colore);
                primaSelezionata = null;
            } catch (IllegalArgumentException ex) {
                primaSelezionata.setStyle(stilePlugLibero);
                primaSelezionata = null;
                cliccata.setStyle(stilePlugErrore);
            }
        }
    }

    @FXML
    private void onResetPressed() {
        macchina.reset();
        inputArea.clear();
        outputArea.clear();
        contatoreCaratteri = 0;
        contatoreCoppie = 0;
        aggiornaDisplayRotori();
        for (Label l : lampade) {
            l.setStyle(stileLampadaOff);
        }
        primaSelezionata = null;
        for (Label l : plugboardLabels) {
            l.setStyle(stilePlugLibero);
        }
    }
}