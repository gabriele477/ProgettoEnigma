package com.bianolini.progetto_enigma;

public class Riflettore {

    private String cablaggio;

    public Riflettore(String cablaggio) {
        this.cablaggio = cablaggio;
    }

    public int rifletti(int segnale) {
        char letteraRimappata = cablaggio.charAt(segnale);
        return letteraRimappata - 'A';
    }
}