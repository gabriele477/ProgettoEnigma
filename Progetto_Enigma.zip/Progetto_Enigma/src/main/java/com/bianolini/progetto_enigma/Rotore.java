package com.bianolini.progetto_enigma;

public class Rotore {
    private String cablaggio;
    private int posizione;
    private char scatto;

    public Rotore(String cablaggio, char scatto){
        this.cablaggio = cablaggio;
        this.scatto = scatto;
        this.posizione = 0;
    }

    public void Ruota(){
        posizione = (posizione + 1) %26;
    }

    //indica se il rotore è arrivato alla posizione a cui deve scattare
    public boolean deveScattare(){
        return (char)('A' + posizione) == scatto;
    }

    //i prossimi due metodi servono a cifrare gli input. il primo lo cifra e il secondo serve per fare capire alla macchina che lampada accendere
    public int cifraInput(int lettera){
        int indice = (lettera + posizione) %26;
        int uscita = cablaggio.charAt(indice) - 'A';
        return (uscita - posizione + 26) %26;
    }

    public int accendiLampada (int lettera){
        int indice = (lettera + posizione) %26;
        int uscita = cablaggio.indexOf('A' + indice);
        return (uscita - posizione + 26) %26;
    }

    public int getPosizione(){
        return posizione;
    }

    public void setPosizione (int pos){
        this.posizione = pos;
    }


}
