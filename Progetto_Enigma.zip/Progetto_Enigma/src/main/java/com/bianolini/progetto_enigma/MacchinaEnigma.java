package com.bianolini.progetto_enigma;

public class MacchinaEnigma {
    private Rotore rotore1, rotore2, rotore3;
    private Riflettore riflettore;
    private Plugboard plugboard;

    public MacchinaEnigma(Rotore rotore1, Rotore rotore2, Rotore rotore3, Riflettore riflettore, Plugboard plugboard){
        this.rotore1 = rotore1;
        this.rotore2 = rotore2;
        this.rotore3 = rotore3;
        this.riflettore = riflettore;
        this.plugboard = plugboard;
    }


    private void ruotaRotori() {
        boolean scatto3 = rotore3.deveScattare();
        boolean scatto2 = rotore2.deveScattare();

        if (scatto2) rotore1.Ruota();
        if (scatto3 || scatto2) rotore2.Ruota();
        rotore3.Ruota();
    }


    public char cifraLettera(char c) {
        c = Character.toUpperCase(c);
        if (c < 'A' || c > 'Z') return c;


        ruotaRotori();


        int segnale = c - 'A';


        segnale = plugboard.scambia(segnale);


        segnale = rotore3.cifraInput(segnale);
        segnale = rotore2.cifraInput(segnale);
        segnale = rotore1.cifraInput(segnale);


        segnale = riflettore.rifletti(segnale);


        segnale = rotore1.accendiLampada(segnale);
        segnale = rotore2.accendiLampada(segnale);
        segnale = rotore3.accendiLampada(segnale);


        segnale = plugboard.scambia(segnale);


        return (char) ('A' + segnale);
    }

    public void reset() {
        rotore1.setPosizione(0);
        rotore2.setPosizione(0);
        rotore3.setPosizione(0);
    }

    public Rotore getRotore1() {
        return rotore1;
    }
    public Rotore getRotore2() {
        return rotore2;
    }
    public Rotore getRotore3() {
        return rotore3;
    }

    public Plugboard getPlugboard() {
        return plugboard;
    }
}