module com.bianolini.progetto_enigma {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.bianolini.progetto_enigma to javafx.fxml;
    exports com.bianolini.progetto_enigma;
}